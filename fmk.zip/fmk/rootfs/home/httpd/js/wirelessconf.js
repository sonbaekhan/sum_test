<script>

// wirelessconf_advancedsetup
function SetToDefault()
{
        var F=document.wireless_params_fm;
        if(F.tx_power) F.tx_power.value = 100;
        if(F.beacon) F.beacon.value = 100;
        if(F.rts) F.rts.value = 2347;
        if(F.frag) F.frag.value = 2346;
        if(F.bg_protect) F.bg_protect[0].checked = true;
        if(F.preamble) F.preamble[0].checked = true;
        if(F.short_slot) F.short_slot[0].checked = true;
        if(F.tx_burst) F.tx_burst[0].checked = true;
        if(F.aggregation) F.aggregation[0].checked = true;
        if(F.afterburner) F.afterburner[0].checked = true;
        if(F.rdg) F.rdg[0].checked = true;
        if(F.channel_width) F.channel_width[0].checked = true;
}

function InitWirelessAdvancedMenu(F, mode)
{
        if(mode != WIRELESS_AP_MODE)
        {
                DisableObj(F.tx_power);
                DisableObj(F.beacon);
                DisableObjNames('bg_protect');
        }
}

function ApplyWirelessParams()
{
        var F=document.wireless_params_fm;

        if((F.tx_power.value > 100 ) || (F.tx_power.value < 1 ))
        {
                alert(DESC_INVALID_TX_POWER);
                F.tx_power.focus();
                return;
        }
        else if((F.rts.value > 2347 ) || (F.rts.value < 1 ))
        {
                alert(DESC_INVALID_RTS_THRESHOLD);
                F.rts.focus();
                return;
        }
        else if((F.frag.value > 2346 ) || (F.frag.value < 256 ))
        {
                alert(DESC_INVALID_FRAG_THRESHOLD);
                F.frag.focus();
                return;
        }
        else if((F.beacon.value > 1024 ) || (F.beacon.value < 50 ))
        {
                alert(DESC_INVALID_BEACON_INTERVAL);
                F.beacon.focus();
                return;
        }
        F.paramsact.value ="1";
        F.submit();
}

// wirelessconf_wdssetup
function WDSRun()
{
        var F = document.wdssetup_fm;
        F.act.value = "run";
        F.submit();
}

function WDSDelete() 
{
	var F = document.wdssetup_fm; 

	if(CheckAtleastOneCheck('delchk') == false) 
	{
		alert(MSG_NO_DEL_WDS);
		return;
	}

	if (confirm(MSG_WDS_DEL_WARNING))
	{
		F.act.value = "del";
	       	F.submit();
	}
}

function AddWDS() 
{
	var F = document.wdssetup_fm;
	var obj;
	if(obj=CheckHW('wdshw'))
	{
                alert(MSG_INVALID_HWADDR);
		obj.focus();
		obj.select();
		return;
	}
        F.act.value = 'add';
        F.submit();
}

var WDS_OFF=0
var WDS_MASTER_MODE=1
var WDS_SLAVE_MODE=2

function Add_MSWDS()
{
	var F = document.wdssetup_fm;
	var obj;

	if(F.wds_name == '')
	{
                alert(MSG_BLANK_SSID);
		F.wds_name.focus();
		F.wds_name.select();
		return;
	}
        F.act.value = 'apply';
        F.submit();
}


function ChangeWdsMode()
{
	var F = document.wdssetup_fm;
        var mode = GetRadioValue(F.wds_mode);

	if( (mode == WDS_OFF) || (mode == WDS_MASTER_MODE))
	{
		DisableObj(F.wds_name);
		DisableObj(F.search_ap_bt);
		DisableRadio(F.prefer_mode);
	}
	else if(mode == WDS_SLAVE_MODE)
	{
		EnableObj(F.wds_name);
		EnableObj(F.search_ap_bt);
		EnableRadio(F.prefer_mode);
	}

}

// wirelessconf_macauth
// actval - policy, delmac, 
function ApplyMacAuth(actval)
{
        var F;
        if(actval=='policy')
                F=document.macauth_fm;
        else
	{
		document.macauth_fm.del_allchk.checked = false;
                F= macauth_dblist.document.macauth_dblist_fm;
	}

        F.act.value=actval;
        F.submit();
}

function AddMacAuth()
{
        var F= macauth_pcinfo.document.macauth_pcinfo_fm;
        var ifrname=macauth_pcinfo;

        if(F.manual_check.checked == true)
        {
                if(obj=CheckHWObj(ifrname,'hw'))
                {
                        alert(MSG_INVALID_HWADDR);
                        obj.focus();
                        obj.select();
                        return;
                }
        }

	document.macauth_fm.add_allchk.checked = false;
        F.act.value = 'addmac';
        F.submit();
}

function ChangeManualCheck()
{
        var F= document.macauth_pcinfo_fm;
        if(F.manual_check.checked == true)
	{
                EnableHW('hw');
		EnableObj(F.info);
	}
        else
	{
                DisableHW('hw');
		DisableObj(F.info);
	}
}

function InitMacAuthObj()
{
        var F= document.macauth_pcinfo_fm;

        DisableHW('hw');
	DisableObj(F.info);
}

function SubmitOtherIframe(act)
{
        var F;
        if(act=='addmac')
	{
                F= parent.macauth_dblist.document.macauth_dblist_fm;
		F.submit();
	}
        else if(act=='delmac')
	{
                F= parent.macauth_pcinfo.document.macauth_pcinfo_fm;
		F.submit();
	}

}

// wirelessconf_basicconf
function ChangeMBridgeAP()
{
	var F=document.basicsetup_fm;

	if(F.mbridge_apuse[1].checked == true ) // stop 
	{
		DisableObj(F.ssid);
		DisableObj(F.broadcast_ssid[0]);
		DisableObj(F.broadcast_ssid[1]);
	}
	else
	{
		EnableObj(F.ssid);
		EnableObj(F.broadcast_ssid[0]);
		EnableObj(F.broadcast_ssid[1]);
	}
}

function ChangeWirelessOp(mode)
{
	var F=document.basicsetup_fm;
	var obj;

	if(mode == 0)
	{
		DisableAllObj(F);
		obj=document.getElementsByName('tmenu');
		if(obj[0]) EnableObj(obj[0]);
		obj=document.getElementsByName('smenu');
		if(obj[0]) EnableObj(obj[0]);
		obj=document.getElementsByName('act');
		if(obj[0]) EnableObj(obj[0]);
		obj=document.getElementsByName('run');
		if(obj[0]) EnableObj(obj[0]);
		if(obj[1]) EnableObj(obj[1]);

		obj=document.getElementsByName('apply_bt');
		if(obj[0]) EnableObj(obj[0]);
	}
	else
		EnableAllObj(F);
	ChangeWirelessMode();
	ChangeWirelessAuth(F);
}

function ChangeChannelConfig(flag)
{
	var F=document.basicsetup_fm;
	var autochannel;

       	var run = GetRadioValue(F.run);

	if(run == 0) 
	{
		DisableObj(F.channel);
		return;
	}

	autochannel=GetValue(F.auto_channel);
	if(autochannel == 1)
	{
		if(!flag || confirm(MSG_MBRIDGE_AUTO_CHANNEL_STRING)) 
		{
			DisableObj(F.channel);
			SetRadioValue(F.auto_channel, 1);
		}
		else
		{
			EnableObj(F.channel);
			SetRadioValue(F.auto_channel,0);
		}
	}
	else
	{
		EnableObj(F.channel);
	}
}


function ChangeWirelessMode()
{
        var F=document.basicsetup_fm;
        var run = GetRadioValue(F.run);
        var obj;
	var wireless_mode;

        obj = document.getElementById('mbridge_opt0');
        if(obj) obj.style.display = "none";
        obj = document.getElementById('mbridge_opt1');
        if(obj) obj.style.display = "none";
        obj = document.getElementById('mbridge_opt2');
        if(obj) obj.style.display = "none";
        obj = document.getElementById('cbridge_opt0');
        if(obj) obj.style.display = "none";
        obj = document.getElementById('wwan_opt0');
        if(obj) obj.style.display = "none";
        obj = document.getElementById('ap_opt0');
        if(obj) obj.style.display = "none";

	if(F.wireless_mode)
		wireless_mode = GetRadioValue(F.wireless_mode);
	else
		wireless_mode = WIRELESS_AP_MODE;

        if(wireless_mode == WIRELESS_AP_MODE)
        {
                if(run!=0) 
		{
			EnableObjNames('broadcast_ssid'); 
			EnableObjNames('channel'); 
			EnableObjNames('search_channel_bt');
			if( F.wmm ) EnableObjNames('wmm');
		}
                DisableObj(F.wmac_chk);
		DisableHW('hw');
        }
        else if(wireless_mode == WIRELESS_CBRIDGE_MODE)
        {
                if(run!=0) 
		{
			EnableObj(F.wmac_chk);
                	EnableObjNames('search_ap_bt');
		}
                if(F.wmac_chk.checked == false)
                        DisableHW('hw');
                else if(run!=0)
                        EnableHW('hw');
                DisableObjNames('broadcast_ssid');
                DisableObjNames('channel');
                DisableObjNames('search_channel_bt');
		if( F.wmm ) DisableObjNames('wmm');
        }
	 else if(wireless_mode == WIRELESS_CWAN_MODE)
        {
		 if(run!=0) 
                	EnableObjNames('search_ap_bt');

                DisableObj(F.wmac_chk);
                DisableHW('hw');
                DisableObjNames('broadcast_ssid');
                DisableObjNames('channel');
                DisableObjNames('search_channel_bt');
		if( F.wmm ) DisableObjNames('wmm');

        }
        else if(wireless_mode == WIRELESS_MBRIDGE_MODE)
        {
		if (navigator.appName.indexOf("Microsoft") != -1)
		{
			obj = document.getElementById('ap_opt0');
                        if(obj) obj.style.display = "block";
                        obj = document.getElementById('mbridge_opt0');
                        if(obj) obj.style.display = "block";
                        obj = document.getElementById('mbridge_opt1');
                        if(obj) obj.style.display = "block";
                        obj = document.getElementById('mbridge_opt2');
                        if(obj) obj.style.display = "block";
		}
		else
		{
			obj = document.getElementById('ap_opt0');
                        if(obj) obj.style.display = "table-row";
                        obj = document.getElementById('mbridge_opt0');
                        if(obj) obj.style.display = "table-row";
                        obj = document.getElementById('mbridge_opt1');
                        if(obj) obj.style.display = "table-row";
                        obj = document.getElementById('mbridge_opt2');
                        if(obj) obj.style.display = "table-row";
		}
					

                obj = document.getElementById('cbridge_opt0');
                if(obj) obj.style.display = "none";

                ChangeMBridgeAP();
        }
       
}

function ChangeWirelessAuth(F)
{
        var obj;
        var auth_type=F.auth_type.value;
        var run = GetValue(F.run);
        var encrypt_type = GetRadioValue(F.encrypt_type);

        DisableRadio(F.encrypt_type);
        if((auth_type == AUTH_OPEN) || (auth_type == AUTH_AUTO))
        {
                if(run != 0)
                {
                        EnableObj(F.encrypt_type[IDX_NOENC]);
                        EnableObj(F.encrypt_type[IDX_WEP64]);
                        EnableObj(F.encrypt_type[IDX_WEP128]);
                }

                if(encrypt_type == ENCRYPT_TKIP || encrypt_type== ENCRYPT_AES || encrypt_type == ENCRYPT_TKIPAES )
                        F.encrypt_type[IDX_NOENC].checked = true;
        }
        else if(auth_type == AUTH_KEY)
        {
                if(run != 0)
                {
                        EnableObj(F.encrypt_type[IDX_WEP64]);
                        EnableObj(F.encrypt_type[IDX_WEP128]);
                }

                if(encrypt_type == ENCRYPT_TKIP || encrypt_type== ENCRYPT_AES || encrypt_type == ENCRYPT_TKIPAES || encrypt_type == ENCRYPT_OFF )
                        F.encrypt_type[IDX_WEP64].checked = true;
        }
        else if((auth_type == AUTH_WPAPSK) || (auth_type == AUTH_WPA2PSK)
                        || (auth_type == AUTH_WPAPSKWPA2PSK) || (auth_type == AUTH_WPANONE))
        {
                if(run != 0)
                {
                        EnableObj(F.encrypt_type[IDX_TKIPAES]);
                        EnableObj(F.encrypt_type[IDX_TKIP]);
                        EnableObj(F.encrypt_type[IDX_AES]);
                }
                if(encrypt_type == ENCRYPT_64 || encrypt_type == ENCRYPT_128 || encrypt_type == ENCRYPT_OFF )
                        F.encrypt_type[IDX_TKIP].checked = true;
        }
        ChangeWirelessEnc(F);
}

function ChangeWirelessEnc(F)
{
        if(document.getElementById('wpapsk_key'))
        {
                var encrypt_type = GetRadioValue(F.encrypt_type);

                document.getElementById('wpapsk_key').style.display = "none";
                document.getElementById('wep_key').style.display = "none";

                if(encrypt_type == ENCRYPT_64 || encrypt_type== ENCRYPT_128)
		{
                	if (navigator.appName.indexOf("Microsoft") != -1)
                        	document.getElementById('wep_key').style.display = "block";
			else
                       		document.getElementById('wep_key').style.display = "table-row";
		}
                if(encrypt_type == ENCRYPT_TKIP || encrypt_type== ENCRYPT_AES || encrypt_type== ENCRYPT_TKIPAES )
		{
                	if (navigator.appName.indexOf("Microsoft") != -1)
                       		document.getElementById('wpapsk_key').style.display = "block";
			else
                       		document.getElementById('wpapsk_key').style.display = "table-row";
		}

                ChangeWirelessKeyInput(F,0);
        }
}

function SetWEPKeySize(F,size, reset)
{
        F.wep_key1.size = size;
        F.wep_key1.maxLength = size;
        if(reset) F.wep_key1.value='';
        F.wep_key2.size = size;
        F.wep_key2.maxLength = size;
        if(reset) F.wep_key2.value='';
        F.wep_key3.size = size;
        F.wep_key3.maxLength = size;
        if(reset) F.wep_key3.value='';
        F.wep_key4.size = size;
        F.wep_key4.maxLength = size;
        if(reset) F.wep_key4.value='';

	if( F.wep_key1.value.length != size ) F.wep_key1.value='';
	if( F.wep_key2.value.length != size ) F.wep_key2.value='';
	if( F.wep_key3.value.length != size ) F.wep_key3.value='';
	if( F.wep_key4.value.length != size ) F.wep_key4.value='';

}

function ChangeWirelessKeyInput(F,reset)
{
        var keysize;
        var encrypt_type = GetRadioValue(F.encrypt_type);
        var key_input = GetRadioValue(F.key_input);

        if(encrypt_type == ENCRYPT_64 || encrypt_type== ENCRYPT_128)
        {
                if(encrypt_type== ENCRYPT_64)
                        keysize = 5;
                else if(encrypt_type== ENCRYPT_128)
                        keysize = 13;
                if(key_input == KEY_HEX)
                        keysize = keysize * 2;
		F.key_length_desc.value = "(" + MSG_KEY_LENGTH_DESC + keysize + ")";

                SetWEPKeySize(F,keysize, reset);
        }
}

function ChangeWirelessRegion()
{
	var F=document.basicsetup_fm;
	var chnum;

       	count = GetOptionCount(F.channel);
	if(F.region.value == REGION_USA)
		chnum=11;
	else if(F.region.value == REGION_JAPAN)
		chnum=14;
	else 
		chnum=13;

	if(chnum < count )
		RemoveOptionTail(F.channel,count,count-chnum);
	else if(chnum > count )
		AddOptionTail(F.channel,count,chnum-count);
}

function CheckWEPKeyLength(prefix,length)
{
	var i, allblank = 1;

	for( i = 1 ; i <= 4; i++)
	{
		obj=document.getElementsByName(prefix+i);
		if(!obj)
		{
			alert("Debug: Invalid Key Obj "+prefix+i);
			return 0;
		}
		if(obj[0].value.length) allblank = 0;
		if(obj[0].value && obj[0].value.length != length)
			return obj[0];
	}

	if(allblank)
	{
		obj=document.getElementsByName(prefix+'1');
		return obj[0];
	}
	return 0; 
}



function CheckWEPKeyHex(prefix)
{
	var i, allblank = 1;

	for( i = 1 ; i <= 4; i++)
	{
		obj=document.getElementsByName(prefix+i);
		if(!obj)
		{
			alert("Debug: Invalid Key Obj "+prefix+i);
			return 0;
		}
		if(obj[0].value.length) allblank = 0;
		if(IsHex(obj[0].value)) return obj[0];
	}

	if(allblank)
	{
		obj=document.getElementsByName(prefix+'1');
		return obj[0];
	}
	return 0; 
}


function ApplyWirelessConfig(o_wmode)
{
        var F=document.basicsetup_fm;
        var obj;
	var run=GetRadioValue(F.run);

        if( (run==1) && F.ssid.value == '')
        {
                alert(MSG_BLANK_SSID);
                F.ssid.focus();
                return;
        }
        var wireless_mode = GetRadioValue(F.wireless_mode);
        var encrypt_type = GetRadioValue(F.encrypt_type);
        var auth_type = GetRadioValue(F.auth_type);

        if(wireless_mode == WIRELESS_CBRIDGE_MODE)
        {
                if(F.wmac_chk.checked == true && (obj=CheckHW('hw')))
                {
                        alert(MSG_INVALID_HWADDR);
                        obj.focus();
                        obj.select();
                        return;
                }
        }

        // in case of mbridge ... should be added
        // security check
        if(encrypt_type == ENCRYPT_64|| encrypt_type == ENCRYPT_128)
        {
                var key_length, i,obj;
                var key_input = GetRadioValue(F.key_input);

                (encrypt_type == ENCRYPT_64)?(key_length = 5):(key_length = 13);
                if(key_input == KEY_HEX) key_length = key_length * 2;

                if(obj=CheckWEPKeyLength("wep_key",key_length))
                {
                        alert(MSG_INVALID_WEP_KEY_LENGTH);
                        obj.focus();
                        obj.select();
                        return;
                }

                if(key_input == KEY_HEX)
                {
                        if(obj=CheckWEPKeyHex("wep_key",key_length))
                        {
                                alert(MSG_INVALID_WEP_KEY_HEXVALUE);
                                obj.focus();
                                obj.select();
                                return;
                        }
                }
        }
        else if(encrypt_type  == ENCRYPT_TKIP || encrypt_type == ENCRYPT_AES || encrypt_type == ENCRYPT_TKIPAES)
        {
                if(F.wpapsk_key.value.length < 8)
                {
                        alert(MSG_INVALID_WPAPSK_KEY_LENGTH);
                        F.wpapsk_key.focus();
                        F.wpapsk_key.select();
                        return;
                }
        }

	if(F.modechange)
	{
                if(o_wmode != wireless_mode)
                {
                        F.modechange.value = 1; 
 
 	       	if((wireless_mode == WIRELESS_AP_MODE) && !confirm(MSG_RESTART_CONFIRM_WIRELESS)) return;
                        else if((wireless_mode == WIRELESS_CBRIDGE_MODE) && !confirm(MSG_RESTART_CONFIRM_WIRELESS_CBRIDGE)) return;
                        if((wireless_mode == WIRELESS_CWAN_MODE) && !confirm(MSG_RESTART_CONFIRM_WIRELESS_WWAN)) return;
                }
                else
                        F.modechange.value = 0;
	}


	if(F.smenu.value == 'multibridge' && F.wwan_enable)
	{
		run=GetRadioValue(F.run);
		wwan=GetRadioValue(F.wwan_enable);

		if(run == 1  && wwan == 1)
		{
			if(!confirm(MSG_DEL_WWAN_WANRING))
				return;
		}
	}



        F.act.value = "apply";
        F.submit();
}


function OnDBLClickAPScanNoWizard(idx)
{
      var obj, encrypt_type, doc;

      if(idx == -1) 
      {
	      idx = parseInt(parent.iframe_scan.document.aplist_fm.apidx.value);
	      doc = parent.iframe_scan.document;
      }
      else
	      doc = document;

      if(doc.scan_fm.scan_type.value == 'wds')
      {
	      obj=doc.getElementsByName('ssid');

	      if(!parent.opener.document.wdssetup_fm)
	      {
		      alert( MSG_OPENER_PAGE_MOVED );
		      parent.close();
		      return;
	      }
	      parent.opener.document.wdssetup_fm.wds_name.value = obj[idx].value;

	      obj=doc.getElementsByName('bssid');
	      SetHWDoc( parent.opener.document, 'wdshw', obj[idx].value ); 

              alert(MSG_APADD_REQUEST_APPLY);
              parent.opener.focus();
	      parent.close();
	      return;
      }


      if(!parent.opener.document.basicsetup_fm)
      {
	      alert( MSG_OPENER_PAGE_MOVED );
	      parent.close();
	      return;
      }

      obj=doc.getElementsByName('ssid');
      parent.opener.document.basicsetup_fm.ssid.value = obj[idx].value;
      obj=doc.getElementsByName('bssid');
      parent.opener.document.basicsetup_fm.bssid.value = obj[idx].value;
      obj=doc.getElementsByName('auth_type');
      if(obj[idx].value == AUTH_AUTO)
	      obj[idx].value = AUTH_OPEN;
      parent.opener.document.basicsetup_fm.auth_type.value = obj[idx].value;

      obj=doc.getElementsByName('encrypt_type');
      SetRadioValue(parent.opener.document.basicsetup_fm.encrypt_type, obj[idx].value );
      encrypt_type = obj[idx].value;

      ChangeWirelessAuth(parent.opener.document.basicsetup_fm);
      ChangeWirelessKeyInput(parent.opener.document.basicsetup_fm,1);
      parent.opener.document.getElementById('wpapsk_key').style.display = "none";
      parent.opener.document.getElementById('wep_key').style.display = "none";


      if (navigator.appName.indexOf("Microsoft") != -1)
      {
	      if(encrypt_type == ENCRYPT_64 || encrypt_type== ENCRYPT_128)
		      parent.opener.document.getElementById('wep_key').style.display = "block";
	      if(encrypt_type == ENCRYPT_TKIP || encrypt_type== ENCRYPT_AES || encrypt_type== ENCRYPT_TKIPAES)
		      parent.opener.document.getElementById('wpapsk_key').style.display = "block";
      }
      else
      {
	      if(encrypt_type == ENCRYPT_64 || encrypt_type== ENCRYPT_128)
		      parent.opener.document.getElementById('wep_key').style.display = "table-row";
	      if(encrypt_type == ENCRYPT_TKIP || encrypt_type== ENCRYPT_AES || encrypt_type== ENCRYPT_TKIPAES)
		      parent.opener.document.getElementById('wpapsk_key').style.display = "table-row";
      }

      if(parent.opener.document.basicsetup_fm.channel)
      {
            obj = doc.getElementsByName('channel');
            parent.opener.document.basicsetup_fm.channel.value = obj[idx].value;
      }

      if(parent.opener.document.basicsetup_fm.ssid.value == '')
      {
              alert(MSG_BLANK_REQUEST_SSID);
              parent.opener.focus();
              parent.opener.document.basicsetup_fm.ssid.focus();
      }
      else if(encrypt_type == ENCRYPT_64 || encrypt_type== ENCRYPT_128)
      {
              alert(MSG_INVALID_REQUEST_KEY);
              parent.opener.focus();
              parent.opener.document.basicsetup_fm.wep_key1.focus();
              parent.opener.document.basicsetup_fm.wep_key1.select();
	      SetRadioValue(parent.opener.document.basicsetup_fm.default_key, '1' );

      }
      else if(encrypt_type == ENCRYPT_TKIP || encrypt_type== ENCRYPT_AES || encrypt_type== ENCRYPT_TKIPAES)
      {
              alert(MSG_INVALID_REQUEST_KEY);
              parent.opener.focus();
              parent.opener.document.basicsetup_fm.wpapsk_key.focus();
              parent.opener.document.basicsetup_fm.wpapsk_key.select();
      }
      else
      {
              alert(MSG_INVALID_REQUEST_APPLY);
              parent.opener.focus();
      }

      parent.close();
}

function OnDBLClickChannelScanNoWizard(idx)
{
      if(!parent.opener.self.document.basicsetup_fm)
      {
	      alert( MSG_OPENER_PAGE_MOVED );
	      parent.close();
	      return;
      }

        if(idx == -1) idx = parseInt(parent.iframe_scan.document.channellist_fm.channel_idx.value);
        alert(MSG_APPLY_REQUEST_KEY);

        parent.opener.self.document.basicsetup_fm.channel.value = idx+1;
        parent.opener.self.document.basicsetup_fm.channel.focus();
        parent.opener.focus();
        parent.close();
}


// wirelessconf_multibssid
function ApplyMultiBssid()
{
        var F=document.mbssid_fm;
        var obj;

        if(F.ssid.value == '')
        {
                alert(MSG_BLANK_SSID);
                F.ssid.focus();
                return;
        }

        var encrypt_type = GetRadioValue(F.encrypt_type);
        var auth_type = GetRadioValue(F.auth_type);

        // in case of mbridge ... should be added
        // security check
        if(encrypt_type == ENCRYPT_64|| encrypt_type == ENCRYPT_128)
        {
                var key_length, i,obj;
                var key_input = GetRadioValue(F.key_input);

                (encrypt_type == ENCRYPT_64)?(key_length = 5):(key_length = 13);
                if(key_input == KEY_HEX) key_length = key_length * 2;

                if(obj=CheckWEPKeyLength("wep_key",key_length))
                {
                        alert(MSG_INVALID_WEP_KEY_LENGTH);
                        obj.focus();
                        obj.select();
                        return;
                }

                if(key_input == KEY_HEX)
                {
                        if(obj=CheckWEPKeyHex("wep_key",key_length))
                        {
                                alert(MSG_INVALID_WEP_KEY_HEXVALUE);
                                obj.focus();
                                obj.select();
                                return;
                        }
                }
        }
        else if(encrypt_type  == ENCRYPT_TKIP || encrypt_type == ENCRYPT_AES || encrypt_type== ENCRYPT_TKIPAES)
        {
                if(F.wpapsk_key.value.length < 8)
                {
                        alert(MSG_INVALID_WPAPSK_KEY_LENGTH);
                        F.wpapsk_key.focus();
                        F.wpapsk_key.select();
                        return;
                }
        }

        F.act.value = "add";
        F.submit();
}

var CheckStatus = 0;
function SetCheckStatus()
{
	CheckStatus = 1;
}

function ModifyMBSS(F,idx)
{
        var i, trobj;
        var obj;

	if(CheckStatus == 1) 
	{
		CheckStatus = 0;
		return;
	}

        for( i=0; ; i++)
        {
                trobj = document.getElementById('tr_'+i);
                if(!trobj) break;
                trobj.className = 'big_td';

                textobj = document.getElementById('ssid_text_'+i);
                if(!textobj) break;
                else textobj.className = 'item_text';

                textobj = document.getElementById('desc_text_'+i);
                if(!textobj) break;
                else textobj.className = 'gray_text';

                textobj = document.getElementById('run_text_'+i);
                if(!textobj) break;
                else textobj.className = 'gray_text';
        }

        trobj = document.getElementById('tr_'+idx);
        trobj.className = 'big_selected_td';

        textobj = document.getElementById('ssid_text_'+idx);
        textobj.className = 'white_text';
        textobj = document.getElementById('desc_text_'+idx);
        textobj.className = 'white_text';
        textobj = document.getElementById('run_text_'+idx);
        textobj.className = 'white_text';

        obj = document.getElementsByName('m_ssid');
	F.ssid.value = obj[idx].value;
	F.old_ssid.value = obj[idx].value;

        obj = document.getElementsByName('m_mbss_policy');
	SetRadioValue( F.mbss_policy, obj[idx].value );

        obj = document.getElementsByName('m_broadcast_ssid');
	SetRadioValue( F.broadcast_ssid, obj[idx].value );

        obj = document.getElementsByName('m_auth_type');
	F.auth_type.value = obj[idx].value;

        obj = document.getElementsByName('m_enc_type');
	SetRadioValue( F.encrypt_type, obj[idx].value );

        obj = document.getElementsByName('m_wmm');
	if(obj) SetRadioValue( F.wmm, obj[idx].value );

	ChangeWirelessAuth(F);
	ChangeWirelessKeyInput(F,1);
	document.getElementById('wpapsk_key').style.display = "none";
	document.getElementById('wep_key').style.display = "none";
	encrypt_type = GetValue(F.encrypt_type);
	if (navigator.appName.indexOf("Microsoft") != -1)
		display = "block";
	else
		display = "table-row";

        if(encrypt_type == ENCRYPT_64 || encrypt_type== ENCRYPT_128)
                document.getElementById('wep_key').style.display = display;
        if(encrypt_type == ENCRYPT_TKIP || encrypt_type== ENCRYPT_AES || encrypt_type== ENCRYPT_TKIPAES)
                document.getElementById('wpapsk_key').style.display = display;

        obj = document.getElementsByName('m_wepkey1');
	F.wep_key1.value = obj[idx].value;
        obj = document.getElementsByName('m_wepkey2');
	F.wep_key2.value = obj[idx].value;
        obj = document.getElementsByName('m_wepkey3');
	F.wep_key3.value = obj[idx].value;
        obj = document.getElementsByName('m_wepkey4');
	F.wep_key4.value = obj[idx].value;

        obj = document.getElementsByName('m_default_key');
	SetRadioValue(F.default_key, obj[idx].value )

        obj = document.getElementsByName('m_key_type');
	SetRadioValue( F.key_input, obj[idx].value );

        obj = document.getElementsByName('m_wpapsk');
	F.wpapsk_key.value = obj[idx].value;



	F.add_bt.value = MODIFY_OP; 
	F.add_bt.disabled = false; 
	F.cancel_bt.disabled = false; 
}

function CancelMBSS(F)
{
	F.act.value = '';
	F.submit();
}


function DelMBSS(F)
{

        var chkchk=false;

	if(!F.delchk)
		return;

        if(F.delchk.length)
        {
                for (i=0; i < F.delchk.length; i++)
                {
                        if (F.delchk[i].type == 'checkbox')
                                if (F.delchk[i].checked)
                                        chkchk = true;
                }
        }
        else if (F.delchk.checked) 
		chkchk = true;

        if (chkchk == true)
        {
		if(confirm(MSG_DEL_MBSSID_WARNING))
		{
			F.act.value = 'del';
			F.submit();
		}
        } else
                alert(MSG_SELECT_DEL_MBSS);

}

function RunMBSS(F)
{
	F.act.value = 'run';
	F.submit();
}

function ChangeWPSOption()
{
        var F = document.wps_fm;

        if(F.wps_status.value == 'start' )
        {
                DisableObj(F.wps_bt);
                F.advanced_option.disabled = true;
                F.wps_pin.disabled = true;
                F.wps_change_config.disabled = true;
                F.pincode.disabled = true;
                return;
        }

        if(F.advanced_option.checked == true )
        {
                F.wps_pin.disabled = false;
                if(F.wps_pin.checked == true ) F.pincode.disabled = false;
                else F.pincode.disabled = true;
                F.wps_change_config.disabled = false;
        }
        else
        {
                F.wps_pin.disabled = true;
                F.wps_change_config.disabled = true;
                F.pincode.disabled = true;
        }

}

function WPSAddDev()
{
        document.wps_fm.wps_status.value= 'start';
        document.wps_fm.submit();
}


function WPSCancelDev()
{
        parent.document.location.href = "timepro.cgi?tmenu=wirelessconf&smenu=wps&wps_status=stop";
}

function ApplyWirelessRateControl()
{
        var F = document.wireless_rateset_fm;

        F.act.value='1';
        F.submit();
}

function ApplyWMMControl(val)
{
        var F = document.wireless_wmm_fm;

        F.act.value=val;
        F.submit();
}


</script>
